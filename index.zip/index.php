<?php 
$base_url = "http://localhost/ubpkeramasan/";
?>

<!DOCTYPE html>
<html lang="id" class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head><body class="home-6">
		
		<title>Keanekaragaman Hayati - PLN Indonesia Power - UBP Keramasan</title>
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="google-site-verification" content="lOBgUHo_myGo0X1LxFjHM2XDgfTcPoEkc_xFy2Cmzmo">
		<link rel="apple-touch-icon" href="<?=$base_url?>id/kehati/apple-touch-icon.png?format=webp">
		<link rel="icon" href="<?=$base_url?>favicon.ico" type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="./assets/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/flaticon.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/animate.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/owl.carousel.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/off-canvas.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/magnific-popup.css">
		<link rel="stylesheet" href="./assets/css/rsmenu-main.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/nivo-slider.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/preview.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/rs-spacing.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/app.css">
		<link rel="stylesheet" type="text/css" href="./assets/css/responsive.css">
		
		<meta name="google-site-verification" content="Kju-yU8n0LCVwXklD9GYFV7SLpPLD8DCtEqp_yJf924">
		<link rel="canonical" href="<?=$base_url?>id/kehati/ubpkeramasan">
<meta name="title" content="Keanekaragaman Hayati - PLN Indonesia Power - UBP Keramasan">
<meta name="url" content="<?=$base_url?>id/kehati/ubpkeramasan">
<meta name="description"> 
		<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "headline": "Keanekaragaman Hayati"
}
</script>
		

	

	<div b-jngd5uu4s0="" class="offwrap"></div>

	<div b-jngd5uu4s0="" class="main-content text-sm">

		<div class="full-width-header">
			<!--Header Start-->
    <header id="rs-header" class="rs-header style2 header-transparent">
        <!-- Topbar Area Start -->
<div class="topbar-area style1">
	<div class="containers custom">
		<div class="row y-middle">
			<div class="col-lg-7">
				<ul class="topbar-menu">
							<li class="">
								<a href="<?=$base_url?>id/home" target="">Beranda </a>

									<ul class="sub-menu">
									</ul>
							</li>        
							<li class="">
								<a href="<?=$base_url?>id/contact" target="">Hubungi Kami </a>

									<ul class="sub-menu">
									</ul>
							</li>        
							<li class="">
								<a href="#" target="_blank">Karir </a>

									<ul class="sub-menu">
									</ul>
							</li>        
							<li class="">
								<a href="#" target="">Pengadaan </a>

									<ul class="sub-menu">
									</ul>
							</li>        
							<li class="">
								<a href="<?=$base_url?>id/media" target="">Media &amp; Informasi </a>

									<ul class="sub-menu">
									</ul>
							</li>        
				</ul> 
			</div>
			<div class="col-lg-5 text-right">
				<div class="toolbar-sl-share">
					<ul>
						
						<li style="margin-right: 20px !important;"><a href="https://www.instagram.com/plnipubpkeramasan"><i class="fa fa-instagram"></i></a></li>i>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Topbar Area End -->

        <!-- Menu Start -->
        <div class="menu-area menu-sticky">
    <div class="containers custom">
        <div class="row-table">
            <div class="col-cell header-logo">
                <div class="logo-area lg:h-[80px]">
                    <a href="<?=$base_url;?>">
                        <img class="h-auto lazy" src="./assets/images/logo.png" data-src="<?=$base_url?>assets/images/logo.png?format=webp" alt="logo">
                    </a>
                </div>
            </div>
            <div class="col-cell">
                <div class="rs-menu-area">
                    <div class="main-menu">
                        <nav class="rs-menu hidden-md">
                            <ul class="nav-menu">
                                                <li class="menu-item-has-children">
                                                    <a href="<?=$base_url?>id/page/profil-dan-riwayat-singkat" target="">Profil Perusahaan  </a>
                                                        <ul class="sub-menu">
                                                                <li><a href="<?=$base_url?>id/page/profil-dan-riwayat-singkat" target="">Profil dan Riwayat Singkat</a> </li>
                                                                
                                                        </ul>
                                                </li> 
                                                <li class="menu-item-has-children">
                                                    <a href="<?=$base_url?>id/page/informasi-investor" target="">Keanekaragaman Hayati </a>
                                                        <ul class="sub-menu">
                                                                <li><a href="<?=$base_url?>ubpkeramasan" target="">UBP Keramasan</a> </li>
                                                                <li><a href="<?=$base_url?>keramasan" target="">Keramasan</a> </li>
                                                                <li><a href="<?=$base_url?>merahmata" target="">Merah Mata</a> </li>
                                                                <li><a href="<?=$base_url?>indralaya" target="">Indralaya</a> </li>                                                                
                                                        </ul>
                                                </li> 
                                                <!--
                                                <li class="menu-item-has-children">
                                                    <a href="<?=$base_url?>id/page/tata-kelola" target="">Tata Kelola </a>
                                                        <ul class="sub-menu">
                                                                <li><a href="<?=$base_url?>id/page/piagam-dewan-komisaris" target="">Piagam Dewan Komisaris</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/piagam-dewan-direksi" target="">Piagam Dewan Direksi</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/komite-audit" target="">Komite Audit</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/komite-nominasi-dan-remunerasi" target="">Komite Nominasi dan Remunerasi</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/komite-investasi-dan-manajemen-risiko" target="">Komite Investasi dan Manajemen Risiko</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/sekretaris-perusahaan" target="">Sekretaris Perusahaan</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/audit-internal" target="">Internal Audit</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/kode-etik" target="">Kode Etik</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/sistem-pelaporan" target="">Sistem Pelaporan Pelanggaran</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/kebijakan-manajemen-risiko" target="">Kebijakan Manajemen Risiko</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/kebijakan-anti-korupsi" target="">Kebijakan Anti Korupsi</a> </li>
                                                        </ul>
                                                </li> 
                                                <li class="menu-item-has-children">
                                                    <a href="<?=$base_url?>id/page/inovasi-bisnis" target="">Inovasi Bisnis </a>
                                                        <ul class="sub-menu">
                                                                <li><a href="<?=$base_url?>id/page/program-cip" target="">Continuous Improvement Program</a> </li>
                                                        </ul>
                                                </li> 
                                                <li class="menu-item-has-children">
                                                    <a href="<?=$base_url?>id/kehati/ubpkeramasan#" target="">Keberlanjutan </a>
                                                        <ul class="sub-menu">
                                                                <li><a href="<?=$base_url?>id/page/kebijakan-keberlanjutan" target="">Kebijakan Keberlanjutan</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/komite-keberlanjutan" target="">Komite Keberlanjutan</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/inisiatif-keberlanjutan" target="">Inisiatif Keberlanjutan</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/fokus-keberlanjutan" target="">Fokus Keberlanjutan</a> </li>
                                                                <li><a href="<?=$base_url?>id/page/strategi-esg" target="">Strategi ESG</a> </li>
                                                                <li><a href="<?=$base_url?>id/kehati" target="">Program Kehati</a> </li>
                                                        </ul>
                                                </li> 
                                                <li class="menu-item-has-children">
                                                    <a href="<?=$base_url?>id/page/tanggung-jawab-sosial-perusahaan" target="">Tanggung Jawab Sosial </a>
                                                        <ul class="sub-menu">
                                                                <li><a href="<?=$base_url?>id/csr" target="">Ikhtisar Tanggung Jawab Sosial</a> </li>
                                                                <li><a href="<?=$base_url?>id/csr/social-impact-assessment-dan-pelibatan-komunitas" target="">Social Impact Assessment dan Pelibatan Komunitas</a> </li>
                                                                <li><a href="<?=$base_url?>id/csr/program-pemberdayaan-masyarakat" target="">Program Pemberdayaan Masyarakat</a> </li>
                                                                <li><a href="<?=$base_url?>id/csr/desa-energi-berdikari" target="">Desa Energi Berdikari</a> </li>
                                                                <li><a href="<?=$base_url?>id/csr/pendidikan-kesehatan-dan-dampak-ekonomi-tidak-langsung" target="">Pendidikan, Kesehatan dan Dampak Ekonomi Tidak Langsung</a> </li>
                                                        </ul>
                                                </li> 
-->
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="col-cell pr-6 md:pr-0">
                <div class="expand-btn-inner md:pr-8">
                    <ul>
                        <li class="search-parent">
                            <a class="hidden-xs rs-search text-red md:text-white hover:text-red" data-bs-toggle="modal" data-bs-target="#searchModal" href="<?=$base_url?>">
                                <i class="flaticon-search"></i>
                            </a>
                        </li>
                        <li class="humburger md:hidden lg:hidden">
                            <a id="nav-expander" class="nav-expander bar" href="<?=$base_url?>id/kehati/">
                                <div class="bar">
                                    <span class="dot1"></span>
                                    <span class="dot2"></span>
                                    <span class="dot3"></span>
                                    <span class="dot4"></span>
                                    <span class="dot5"></span>
                                    <span class="dot6"></span>
                                    <span class="dot7"></span>
                                    <span class="dot8"></span>
                                    <span class="dot9"></span>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
        <!-- Menu End -->
        <!-- Canvas Menu start -->
        
<!-- Canvas Menu end -->

<!-- Canvas Mobile Menu start -->

        <!-- Canvas Menu end -->
    </header>
    <!--Header End-->
</div>
		
<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs -mt-20 lazy" style="background-image: url('assets/profile.jpg');">
  <div class="container">
    <div class="breadcrumbs-inner">
      <h2 class="page-title">
        Keanekaragaman Hayati
      </h2>
    </div>
  </div>
</div>
<!-- Breadcrumbs End -->

<!-- Blog Section Start -->
<div class="rs-inner-blog pt-100 pb-100 md-pt-70 md-pb-70">
  <div class="container custom">
    <div class="row">
      <!-- Widget -->
      <div class="col-lg-4 col-md-12 order-last">
        <div class="widget-area">
          <div class="categories">
            <div class="widget-title">
              <h3 class="title">Program Lainnya</h3>
            </div>
            <ul>
                      
                      <li>
                        UBP Keramasan
                        <ul>
                          
                            <li><a href="<?=$base_url?>#">KERAMASAN</a></li>
                            <li><a href="<?=$base_url?>#">MERAH MATA</a></li>
                            <li><a href="<?=$base_url?>#">INDRALAYA</a></li>
                            
                        </ul>
                      </li>
                      <li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Main -->
      <div class="col-lg-8 pr-35 md-pr-15 md-mt-50">
        <div class="row">
          <div class="col-lg-12">
            <div class="blog-details">
              <div class="blog-full">
                <div class="flex mb-6 gap-2">
                  <span class="inline-blogk text-white bg-red font-bold py-2 px-4">KEHATI</span>
                </div>
                <h1 class="text-4xl">PLN Indonesia Power - UBP Keramasan</h1>
                <ul class="single-post-meta">
                        <li>
                            <span class="p-date"><i class="fa fa-calendar-check-o"></i>23/09/2024</span>
                        </li>
                  <li>
                    <span class="p-date"> <i class="fa fa-user-o"></i>admin</span>
                  </li>
                </ul>
              </div>
              <div class="bs-img mb-35">
                <img class="lazy" alt="Program Kehati" src="assets/images/laporan.jpg" style="">
              </div>
              <div class="blog-full">
                <p style="text-align:justify;">PT PLN Indonesia Power UBP Keramasan merupakan salah satu Unit UBP di bawah PT PLN Indonesia Power yang sebelumnya bernama PT PLN (Persero) UPDK Keramasan yang secara resmi berganti menjadi PT PLN Indonesia Power UPDK Keramasan sejak tanggal 01 Januari 2023.
PT PLN Indonesia Power UBP Keramasan yang selanjutnya disebut sebagai Perusahaan yang mengelola usaha lainnya yang berkaitan secara efektif dan efisien sesuai kontrak kinerja yang ditetapkan oleh Direksi kecuali pemeliharaan periodik.
Dalam Keputusan Direksi No.303.K/010/IP/2022 tanggal 27 Desember 2022 tentang Organisasi Unit Pelaksana Pengendalian Pembangkitan Keramasan menjelaskan bahwa PT Indonesia Power memiliki 3 (tiga) Unit Pembangkitan yang mengelola kegiatan operasi dan pemeliharaan pembangkit sesuai standar dan kontrak kinerja yang ditetapkan dengan mengendalikan biaya, mutu dan waktu secara effektif dan Efisien.</p>
                
                    <h3>Program Kehati</h3>
                    <table class="table">
                    <thead>
                    <tr><th>JUDUL</th><th>KATEGORI</th><th>DOKUMEN</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Program Kehati UBP Keramasan Tahun 2022</td>
                            <td>Program Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Program Kehati UBP Keramasan Tahun 2024</td>
                            <td>Program Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Program Kehati UBP Keramasan Tahun 2023</td>
                            <td>Program Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                    </tbody></table>
                    <div class="mb-10"></div>
                    <h3>Laporan Status Kehati</h3>
                    <table class="table">
                    <thead>
                    <tr><th>JUDUL</th><th>KATEGORI</th><th>DOKUMEN</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Laporan Status Kehati UBP Keramasan Tahun 2022</td>
                            <td>Laporan Status Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Laporan Status Kehati UBP Keramasan Tahun 2024</td>
                            <td>Laporan Status Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Laporan Status Kehati UBP Keramasan Tahun 2023</td>
                            <td>Laporan Status Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                    </tbody></table>
                    <div class="mb-10"></div>

                    <h3>Inovasi Kehati</h3>
                    <table class="table">
                    <thead>
                    <tr><th>JUDUL</th><th>KATEGORI</th><th>DOKUMEN</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Inovasi Kehati UBP Keramasan Tahun 2022</td>
                            <td>Inovasi Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Inovasi Kehati UBP Keramasan Tahun 2024</td>
                            <td>Inovasi Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Inovasi Kehati UBP Keramasan Tahun 2023</td>
                            <td>Inovasi Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                    </tbody></table>
                    <div class="mb-10"></div>

                    <h3>Publikasi Kehati</h3>
                    <table class="table">
                    <thead>
                    <tr><th>JUDUL</th><th>KATEGORI</th><th>DOKUMEN</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Publikasi Kehati UBP Keramasan Tahun 2022</td>
                            <td>Publikasi Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Publikasi Kehati UBP Keramasan Tahun 2023</td>
                            <td>Publikasi Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                        <tr>
                            <td>Publikasi Kehati UBP Keramasan Tahun 2024</td>
                            <td>Publikasi Kehati</td>
                                <td><a href="<?=$base_url?>#" download="#">Unduh</a></td>
                        </tr>
                    </tbody></table>
                    <div class="mb-10"></div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Blog Section End -->

		<div class="rs-footer relative text-center">
   
    <div class="bg-wrap">
        <div class="footer-content pt-20 pb-20">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-sm-12 md-md-30">
                        <div class="about-widget text-left">
                            <div class="logo-area">
                                <a href="<?=$base_url?>">
                                    <img class="h-auto lazy" src="<?=$base_url?>assets/images/logo.png" data-src="<?=$base_url?>assets/images/logo.png&amp;width=194" srcset="<?=$base_url?>assets/images/PHE_Horizontal_Putih.png?format=webp&amp;width=388 2x" alt="Footer Logo">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="row">
                            <div class="col-lg-3 col-md-12 col-sm-12 md-md-30">
                                <div class="quicklinks-widget widget text-left">
                                    <h4 class="widget-title">Website Kami</h4>
                                    <ul>
                                        <li><a href="<?=$base_url?>#">Kebijakan Privasi</a></li>
                                        <li><a href="<?=$base_url?>#">Waspada Penipuan</a></li>
                                        <li><a href="<?=$base_url?>#">Hubungi Kami</a></li>
                                        <li><a href="<?=$base_url?>#">Peta Situs</a></li>
                                        <li><a href="<?=$base_url?>#">Waspada Penipuan</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 col-sm-12 md-md-30">
                                <div class="categories-widget widget text-left">
                                   
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 col-sm-12">
                                <div class="legal-widget widget text-left">
                                    <h4 class="widget-title">Ikuti Kami</h4>
                                    <ul>
                                        <li>
                                            <a href="https://www.instagram.com/https://www.instagram.com/plnipubpkeramasan/" target="_blank" rel="noopener"><i class="fa fa-instagram text-xl mr-2 w-7 align-middle"></i></a>
                                            <a href="https://www.facebook.com/" target="_blank" rel="noopener"><i class="fa fa-facebook text-xl mr-2 w-7 align-middle"></i></a>
                                            <a href="https://www.linkedin.com/" target="_blank" rel="noopener"><i class="fa fa-linkedin text-xl mr-2 w-7 align-middle"></i></a>
                                            <a href="https://www.youtube.com" target="_blank" rel="noopener"><i class="fa fa-youtube-play text-xl mr-2 w-7 align-middle"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 col-sm-12 mt-5 md:mt-0">
                                <div class="legal-widget widget text-left">
                                    <h4 class="widget-title">Kontak</h4>
                                    <div class="text-white">
                                        <p>
                                           PT PLN Indonesia Power UBP Keramasan
Jl. Ki Merogan Lr. Rawasari Rt. 34 Rw. 07 Kel. Kemang Agung - Kertapati, Palembang 30258
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom text-center">
            <div class="container">
                <p class="copyright">PT Indonesia Power UBP Keramasan © Copyright 2025. All rights reserved.</p>
            </div>
        </div>
    </div>
</div>

		
	</div>    

	<div b-jngd5uu4s0="" id="scrollUp" class="orange-color">
		<i b-jngd5uu4s0="" class="fa fa-angle-up"></i>
	</div>

	<div b-jngd5uu4s0="" class="modal fade search-modal" id="searchModal" tabindex="-1">
		<button b-jngd5uu4s0="" type="button" class="close" data-bs-dismiss="modal">
			<span b-jngd5uu4s0="" class="flaticon-cross"></span>
		</button>
		<div b-jngd5uu4s0="" class="modal-dialog modal-dialog-centered">
			<div b-jngd5uu4s0="" class="modal-content">
				<div b-jngd5uu4s0="" class="search-block clearfix">
					<form action="<?=$base_url?>id/media">
						<div b-jngd5uu4s0="" class="form-group">
							<input b-jngd5uu4s0="" class="form-control" placeholder="Search Here..." type="text" name="q">
							<button b-jngd5uu4s0="" type="submit" value="Search"><i b-jngd5uu4s0="" class="flaticon-search"></i></button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<script src="<?=$base_url?>assets/js/modernizr-2.8.3.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/jquery.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/bootstrap.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/jquery.nav.js.download"></script>
	<script src="<?=$base_url?>assets/js/isotope.pkgd.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/owl.carousel.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/wow.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/skill.bars.jquery.js.download"></script>
	<script src="<?=$base_url?>assets/js/imagesloaded.pkgd.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/waypoints.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/jquery.counterup.min.js.download"></script> 
	<script src="<?=$base_url?>assets/js/jquery.magnific-popup.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/jquery.nivo.slider.js.download"></script>
	<script src="<?=$base_url?>assets/js/jquery.lazy.min.js.download"></script>
	<script src="<?=$base_url?>assets/js/main.js.download"></script>
	
	
</body></html>